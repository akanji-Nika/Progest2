var express = require('express');
var router = express.Router();
var Sequelize = require('sequelize');
const multer = require('multer');
var bodyParser = require("body-parser");
var app = express();
const path = require('path');
var fs = require('fs');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    },
});

//const upload = multer({ storage });
const upload = multer({
    storage,
    fileFilter: (req, file, cb) => {
        const allowedTypes = ['image/jpeg', 'image/png'];
        if (!allowedTypes.includes(file.mimetype)) {
            return cb(new Error('Type de fichier non autorisé'), false);
        }
        cb(null, true);
    },
});


// Configuration de Sequelize
const sequelize = new Sequelize('CommandeDB', 'postgres', 'root09', {
    host: 'localhost',
    dialect: 'postgres',
    port: 6679,
    define: {
        freezeTableName: true,
        timestamps: false
    },
    pool: {
        max: 15,
        min: 0,
        idle: 10000
    }
});

// Vérification de la connexion
sequelize
    .authenticate()
    .then(() => console.log('Connexion à la base de données réussie.'))
    .catch(err => console.error('Erreur de connexion :', err));

// Définition du modèle Sequelize
var Commande = sequelize.define('commande', {
    numcom: {
        type: Sequelize.INTEGER,
        primaryKey: true
    },
    photo: { type: Sequelize.STRING },
    datecom: { type: Sequelize.DATE },
    nomfour: { type: Sequelize.STRING },
    numfour: { type: Sequelize.STRING },
    adressfour: { type: Sequelize.STRING },
    nomprod: { type: Sequelize.STRING },
    quantprod: { type: Sequelize.INTEGER },
    prixunit: { type: Sequelize.INTEGER },
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ "extended": false }));



// Route pour insérer des données
router.post('/InsertDataOnServer', function (req, res) {
    var { datecom, nomfour, numfour, adressfour, nomprod, quantprod, prixunit } = req.body;
    let { photo } = req.body;

    sequelize
        .transaction(async t => {
            // Appliquer un verrou sur la table pour éviter les conflits
            await sequelize.query('LOCK TABLE commande IN EXCLUSIVE MODE', { transaction: t });

            // Calculer le nouvel `numcom`
            const maxId = await Commande.max('numcom', { transaction: t });
            const newId = maxId ? maxId + 1 : 1;

            // Insérer la nouvelle commande
            return Commande.create(
                {
                    numcom: newId,
                    photo: photo,//////////////////////////
                    datecom: datecom,
                    nomfour: nomfour,
                    numfour: numfour,
                    adressfour: adressfour,
                    nomprod: nomprod,
                    quantprod: quantprod,
                    prixunit: prixunit,
                },
                { transaction: t }
            );
        })
        .then(data => {
            res.json({ message: 'Insertion effectuée !', data });
        })
        .catch(err => {
            console.error(err);
            res.json({ message: 'Insertion non effectuée !', error: err });
        });
});




// Route pour modifier les données
router.post('/ModifyDataOnServer', function(req, res) {
    // Extraction des données depuis le corps de la requête
    var { numcom, datecom, nomfour, numfour, adressfour, nomprod, quantprod, prixunit } = req.body;

    if (!numcom) {
        return res.status(400).json({ message: "Le champ 'numcom' est obligatoire." });
    }

    // Démarrer une transaction Sequelize
    sequelize.transaction(async (t) => {
        try {
            // Mise à jour de la commande
            await Commande.update(
                {
                    datecom: datecom,
                    nomfour: nomfour,
                    numfour: numfour,
                    adressfour: adressfour,
                    nomprod: nomprod,
                    quantprod: quantprod,
                    prixunit: prixunit
                },
                { where: { numcom: numcom }, transaction: t }
            );

            // Envoi de la réponse en cas de succès
            res.json({ message: "Modification effectuée !" });
        } catch (err) {
            console.error("Erreur lors de la mise à jour : ", err);

            // Envoi de la réponse en cas d'erreur
            res.status(500).json({ message: "Modification non effectuée !" });
        }
    });
});




// Route pour afficher les données
router.get('/GridCommandeServer', function(req, res) {
    
    Commande.findAll({order: sequelize.col('numcom')}).then(function(result) {
        var taille = result.length;
        var data = result;
        var tableau = [];
        var row;

        for (var i = 0; i < taille; i++) {
            row = {
                numcom: data[i].numcom, 
                photo: data[i].photo,
                datecom: data[i].datecom, 

                nomfour: data[i].nomfour,
                numfour: data[i].numfour,
                adressfour: data[i].adressfour,

                nomprod: data[i].nomprod, 
                quantprod: data[i].quantprod, 
                prixunit: data[i].prixunit,

                //total: data[i].math + data[i].anglais + data[i].informatique+ data[i].poo,
                //moyenne:  Math.round((data[i].math + data[i].anglais + data[i].informatique+ data[i].poo)/4)
            };
            tableau.push(row);
        }

        var grid = {
            success : true, 
            data: tableau
        };
        res.contentType('json');
        res.json(grid);
    });
});



router.post('/UploadFileOnServer', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('Aucun fichier reçu');
    }

    const photo = req.file.filename;
    const [numcom] = photo.split('.');

    sequelize
    .transaction((t) => {
        return Commande.update(
            { photo },
            { where: { numcom }, transaction: t }
        );
    })
    .then(() => res.json({ filePath: photo }))
    .catch((err) => {
        console.error(err);
        res.status(500).json({ message: 'Erreur lors de la mise à jour', error: err });
    });

});


// Exporter le routeur
//app.use('/',router);
module.exports = router;